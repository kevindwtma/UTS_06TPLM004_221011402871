import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'dart:convert';
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(const UTS());
}

class UTS extends StatelessWidget {
  const UTS({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kevin Dwitama',
      debugShowCheckedModeBanner: false,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String city = "Loading...";
  double currentTemp = 0;
  double minTemp = 0;
  double maxTemp = 0;
  String weatherMain = "Loading...";
  String dateStr = DateFormat('EEEE, MMMM d, yyyy').format(DateTime.now());

  @override
  void initState() {
    super.initState();
    _initLocationAndFetchWeather();
  }

  Future<void> _initLocationAndFetchWeather() async {
    final status = await Permission.location.request();

    if (status.isGranted) {
      _fetchWeather();
    } else {
      setState(() {
        city = "Permission denied";
      });
    }
  }

  Future<void> _fetchWeather() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      String apiKey =
          '6591b670739b7c321331507600977f90'; // ← Ganti dengan API key milikmu
      String url =
          'https://api.openweathermap.org/data/2.5/weather?lat=${position.latitude}&lon=${position.longitude}&appid=$apiKey&units=metric';

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        setState(() {
          city = data['name'] ?? 'Unknown';
          currentTemp = data['main']['temp'].toDouble();
          minTemp = data['main']['temp_min'].toDouble();
          maxTemp = data['main']['temp_max'].toDouble();
          weatherMain = data['weather'][0]['main'];
        });
      } else {
        setState(() {
          city = "Failed to load data";
        });
      }
    } catch (e) {
      setState(() {
        city = "Error: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/background.png', fit: BoxFit.cover),
          Container(color: Colors.black.withOpacity(0.4)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 80),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  city,
                  style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  dateStr,
                  style: const TextStyle(fontSize: 18, color: Colors.white70),
                ),
                const SizedBox(height: 50),
                Text(
                  "${currentTemp.round()}°C",
                  style: const TextStyle(
                    fontSize: 80,
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Divider(color: Colors.white70, thickness: 1),
                const SizedBox(height: 10),
                Text(
                  weatherMain,
                  style: const TextStyle(fontSize: 24, color: Colors.white),
                ),
                const SizedBox(height: 8),
                Text(
                  "${minTemp.round()}°C / ${maxTemp.round()}°C",
                  style: const TextStyle(fontSize: 18, color: Colors.white70),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
